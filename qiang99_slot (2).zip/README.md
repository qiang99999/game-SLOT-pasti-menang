# Qiang99 Slot

Demo static website for Qiang99 Slot.

Features: click coin, spin/gacha, referral copy, payout demo.
